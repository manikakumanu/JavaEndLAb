package com.klef.jfsd.lab;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;

public class ClientDemo {
    public static void main(String[] args) {
        Configuration config = new Configuration();
        config.configure("hibernate.cfg.xml");
        SessionFactory sessionFactory = config.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        // Insert Records
        Customer customer1 = new Customer();
        customer1.setName("John Doe");
        customer1.setEmail("john.doe@example.com");
        customer1.setAge(30);
        customer1.setLocation("New York");

        Customer customer2 = new Customer();
        customer2.setName("Jane Smith");
        customer2.setEmail("jane.smith@example.com");
        customer2.setAge(25);
        customer2.setLocation("Los Angeles");

        session.save(customer1);
        session.save(customer2);

        // Commit the transaction for inserted records
        transaction.commit();

        // New transaction for queries
        transaction = session.beginTransaction();

        // Query Customers with age > 28
        CriteriaBuilder cb = session.getCriteriaBuilder();
        CriteriaQuery<Customer> cq = cb.createQuery(Customer.class);
        Root<Customer> root = cq.from(Customer.class);
        cq.select(root).where(cb.gt(root.get("age"), 28));
        List<Customer> result = session.createQuery(cq).getResultList();

        System.out.println("Customers with age > 28:");
        result.forEach(c -> System.out.println(c.getName()));

        // Query Customers with name like 'Jane%'
        cq = cb.createQuery(Customer.class);
        root = cq.from(Customer.class);
        cq.select(root).where(cb.like(root.get("name"), "Jane%"));
        result = session.createQuery(cq).getResultList();

        System.out.println("Customers with name like 'Jane':");
        result.forEach(c -> System.out.println(c.getName()));

        // Query Customers between age 20 and 35
        cq = cb.createQuery(Customer.class);
        root = cq.from(Customer.class);
        cq.select(root).where(cb.between(root.get("age"), 20, 35));
        result = session.createQuery(cq).getResultList();

        System.out.println("Customers between age 20 and 35:");
        result.forEach(c -> System.out.println(c.getName()));

        transaction.commit();
        session.close();
        sessionFactory.close();
    }
}
